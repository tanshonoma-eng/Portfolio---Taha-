document.addEventListener('DOMContentLoaded', function(){

  /* ---------- preloader ---------- */
  var plFill = document.getElementById('pl-fill');
  var preloader = document.getElementById('preloader');
  if(window.gsap){ gsap.to(plFill,{width:'100%',duration:1.1,ease:'power2.inOut'}); }
  window.addEventListener('load', function(){
    setTimeout(function(){
      if(window.gsap){
        gsap.to(preloader,{opacity:0,duration:.6,ease:'power2.out',onComplete:function(){preloader.style.display='none'; runHeroIntro();}});
      } else {
        preloader.style.display='none'; runHeroIntro();
      }
    }, 500);
  });
  // fallback in case load event already fired / slow assets
  setTimeout(function(){
    if(preloader && preloader.style.display !== 'none'){
      if(window.gsap){ gsap.to(preloader,{opacity:0,duration:.5,onComplete:function(){preloader.style.display='none'; runHeroIntro();}}); }
      else { preloader.style.display='none'; runHeroIntro(); }
    }
  }, 2600);

  /* ---------- hero entrance ---------- */
  function runHeroIntro(){
    if(!window.gsap) return;
    var tl = gsap.timeline({defaults:{ease:'power3.out'}});
    tl.to('.hero-headline .lineB span', {y:'0%', duration:1, stagger:0.12})
      .to('#heroSub', {opacity:1, y:0, duration:.8}, '-=0.5')
      .fromTo('#hero3d',{opacity:0, scale:.9},{opacity:1, scale:1, duration:1.2, ease:'power3.out'}, '-=1')
      .to('#heroBottom', {opacity:1, duration:.8}, '-=0.6');
  }

  /* ---------- custom cursor ---------- */
  var dot = document.getElementById('cursorDot');
  window.addEventListener('mousemove', function(e){
    if(window.gsap){ gsap.to(dot,{x:e.clientX,y:e.clientY,duration:.15,ease:'power2.out'}); }
    else { dot.style.left=e.clientX+'px'; dot.style.top=e.clientY+'px'; }
  });
  document.querySelectorAll('a, button, .work-card').forEach(function(el){
    el.addEventListener('mouseenter', function(){ dot.classList.add('grow'); });
    el.addEventListener('mouseleave', function(){ dot.classList.remove('grow'); });
  });

  /* ---------- hero 3D parallax ---------- */
  var stage = document.getElementById('hero3d');
  var scene = document.getElementById('hero3dScene');
  if(stage && scene){
    window.addEventListener('mousemove', function(e){
      var rx = (e.clientX / window.innerWidth - 0.5) * -28;
      var ry = (e.clientY / window.innerHeight - 0.5) * 18;
      scene.style.setProperty('--rx', rx+'deg');
      scene.style.setProperty('--ry', ry+'deg');
    });
  }

  /* ---------- mobile menu ---------- */
  var burger = document.getElementById('burgerBtn');
  var menu = document.getElementById('mobile-menu');
  var closeMenu = document.getElementById('closeMenu');
  burger.addEventListener('click', function(){ menu.classList.add('open'); burger.setAttribute('aria-expanded','true'); });
  closeMenu.addEventListener('click', function(){ menu.classList.remove('open'); burger.setAttribute('aria-expanded','false'); });
  menu.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', function(){ menu.classList.remove('open'); }); });

  /* ---------- scroll reveals ---------- */
  if(window.gsap && window.ScrollTrigger){
    gsap.registerPlugin(ScrollTrigger);
    gsap.utils.toArray('.reveal').forEach(function(el){
      gsap.to(el, {
        opacity:1, y:0, duration:.9, ease:'power3.out',
        scrollTrigger:{ trigger: el, start:'top 88%' }
      });
    });
  } else {
    document.querySelectorAll('.reveal').forEach(function(el){ el.style.opacity=1; el.style.transform='none'; });
  }

  /* ---------- work filter ---------- */
  var tabs = document.querySelectorAll('.work-tab');
  var cards = document.querySelectorAll('.work-card');
  tabs.forEach(function(tab){
    tab.addEventListener('click', function(){
      tabs.forEach(function(t){ t.classList.remove('active'); });
      tab.classList.add('active');
      var f = tab.getAttribute('data-filter');
      cards.forEach(function(c){
        var show = (f==='all' || c.getAttribute('data-cat')===f);
        if(window.gsap){
          gsap.to(c, {opacity: show?1:0, scale: show?1:0.92, duration:.35, onComplete:function(){ c.style.display = show?'':'none'; } });
          if(show){ c.style.display=''; gsap.fromTo(c,{opacity:0},{opacity:1,duration:.35}); }
        } else {
          c.style.display = show ? '' : 'none';
        }
      });
    });
  });

  /* ---------- lightbox ---------- */
  var lb = document.getElementById('lightbox');
  var lbImg = document.getElementById('lbImg');
  var lbTitle = document.getElementById('lbTitle');
  var lbDesc = document.getElementById('lbDesc');
  var lbSub = document.getElementById('lbSub');
  cards.forEach(function(c){
    c.addEventListener('click', function(){
      lbImg.src = c.getAttribute('data-img');
      lbImg.alt = c.getAttribute('data-title');
      lbTitle.textContent = c.getAttribute('data-title');
      lbDesc.textContent = c.getAttribute('data-desc');
      lbSub.textContent = c.getAttribute('data-sub');
      lb.classList.add('open');
    });
  });
  document.getElementById('lbClose').addEventListener('click', function(){ lb.classList.remove('open'); });
  lb.addEventListener('click', function(e){ if(e.target===lb){ lb.classList.remove('open'); } });
  window.addEventListener('keydown', function(e){ if(e.key==='Escape'){ lb.classList.remove('open'); menu.classList.remove('open'); } });

});